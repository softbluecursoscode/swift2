//
//  ViewController.swift
//  EXAutoLayout01
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func supportedInterfaceOrientations() -> Int
    {
        // Comando antigo
        // return Int(UIInterfaceOrientationMask.AllButUpsideDown.toRaw())
        
        // Novo comando
        return Int(UIInterfaceOrientationMask.AllButUpsideDown.rawValue)
    }

}

