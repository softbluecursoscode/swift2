//
//  ViewController.swift
//  CoreLocation
//
//  Created by Andre Milani.
//  Copyright Softblue. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    /*
    Não esqueça da propriedade "NSLocationAlwaysUsageDescription" no arquivo info.plist
    */
    
    @IBOutlet weak var labelLatitude : UILabel!
    @IBOutlet weak var labelLongitude : UILabel!
    @IBOutlet weak var labelAltitude : UILabel!
    @IBOutlet weak var labelPrecisaoHorizontal : UILabel!
    @IBOutlet weak var labelPrecisaoVertical : UILabel!
    @IBOutlet weak var labelDistanciaPercorrida : UILabel!
    
    var locationManager : CLLocationManager!
    var localizacaoDeSaida : CLLocation!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
    }
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: NSDictionary?) -> Bool
    {
        return true
    }
    
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus)
    {
        if(status == CLAuthorizationStatus.AuthorizedAlways)
        {
            locationManager.startUpdatingLocation()
        }
        else
        {
            print("Localização não foi capturada.")
        }
    }
    
    //func locationManager(manager: CLLocationManager, didUpdateLocations locations: [AnyObject])
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        //let newLocation: CLLocation = locations.last as! CLLocation
        let newLocation: CLLocation = locations.last!
        
        if(localizacaoDeSaida == nil)
        {
            localizacaoDeSaida = newLocation
        }
        
        labelLatitude.text = NSString(format: "%g \u{00B0}", newLocation.coordinate.latitude) as String
        labelLongitude.text = NSString(format: "%g \u{00B0}", newLocation.coordinate.longitude) as String
        labelAltitude.text = NSString(format: "%g m", newLocation.altitude) as String
        labelPrecisaoHorizontal.text = NSString(format: "%g m", newLocation.horizontalAccuracy) as String
        labelPrecisaoVertical.text = NSString(format: "%g m", newLocation.verticalAccuracy) as String
        
        let distancia: CLLocationDistance = newLocation.distanceFromLocation(localizacaoDeSaida)
        labelDistanciaPercorrida.text = NSString(format: "%g m", distancia) as String
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

