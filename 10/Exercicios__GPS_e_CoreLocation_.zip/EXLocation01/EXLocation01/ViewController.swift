//
//  ViewController.swift
//  CoreLocation
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var labelLatitude : UILabel!
    @IBOutlet weak var labelLongitude : UILabel!
    @IBOutlet weak var labelAltitude : UILabel!
    @IBOutlet weak var labelPrecisaoHorizontal : UILabel!
    @IBOutlet weak var labelPrecisaoVertical : UILabel!
    @IBOutlet weak var labelDistanciaPercorrida : UILabel!
    
    var locationManager : CLLocationManager!
    var localizacaoDeSaida : CLLocation!
    var estaDentroDoPerimetro : Bool!
    
    //
    // IMPORTANTE *******************************************************************
    //
    // Não esqueça de adicionar no arquivo Info.plist a seguinte entrada:
    // NSLocationAlwaysUsageDescription
    // Com o texto que deve aparecer para o usuário junto na mensagem de autorização.
    // Sem isto, não funciona.
    //
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        
        // É necessário inicializar esta variável para atender a lógica de como o exercício foi criado
        estaDentroDoPerimetro = true
    }
    
    func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!)
    {
        var newLocation : CLLocation = locations.last as CLLocation
        
        if(localizacaoDeSaida == nil)
        {
            localizacaoDeSaida = newLocation
        }
        
        var distancia : CLLocationDistance = newLocation.distanceFromLocation(localizacaoDeSaida)

        labelDistanciaPercorrida.text = NSString(format:"%g m", distancia)
            
        if(distancia > 20 && estaDentroDoPerimetro == true)
        {
            estaDentroDoPerimetro = false
                
            var myAlert : UIAlertView = UIAlertView()
            myAlert.title = "SAÍDA"
            myAlert.message = "Saiu do perímetro"
            myAlert.addButtonWithTitle("OK")
            myAlert.show()
        }
            
        if(distancia <= 20 && estaDentroDoPerimetro == false)
        {
            estaDentroDoPerimetro = true
            
            var myAlert : UIAlertView = UIAlertView()
            myAlert.title = "ENTRADA"
            myAlert.message = "Entrou do perímetro"
            myAlert.addButtonWithTitle("OK")
            myAlert.show()
        }

    }
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: NSDictionary?) -> Bool
    {
        initLocationManager()
        return true
    }
    
    func initLocationManager()
    {
        
    }
    
    func locationManager(manager: CLLocationManager!, didChangeAuthorizationStatus status: CLAuthorizationStatus)
    {
        NSNotificationCenter.defaultCenter().postNotificationName("CL Update", object: nil)
        
        if(status == CLAuthorizationStatus.Authorized)
        {
            locationManager.startUpdatingLocation()
        }
        else
        {
            var myAlert : UIAlertView = UIAlertView()
            myAlert.title = "Erro"
            myAlert.message = "Localização não capturada"
            myAlert.addButtonWithTitle("OK")
            myAlert.show()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}



        
        