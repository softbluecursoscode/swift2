//
//  ViewController.swift
//  EXConfiguracoes01
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var basNomeDeUsuarioLabel : UILabel!
    @IBOutlet weak var basEmailLabel : UILabel!
    @IBOutlet weak var basSenhaLabel : UILabel!
    @IBOutlet weak var basReceberEmailsLabel : UILabel!
    @IBOutlet weak var avConhecimentoLabel : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func updateFields()
    {
        var myUserDefaults = NSUserDefaults.standardUserDefaults()
    
        basNomeDeUsuarioLabel.text = myUserDefaults.stringForKey("basNomeDeUsuario")
        basEmailLabel.text = myUserDefaults.stringForKey("basEmail")
        basSenhaLabel.text = myUserDefaults.stringForKey("basSenha")
        
        if(myUserDefaults.boolForKey("basReceberEmails") == true)
        {
            basReceberEmailsLabel.text = "Sim"
        }
        else
        {
            basReceberEmailsLabel.text = "Não"
        }
        
        avConhecimentoLabel.text = myUserDefaults.stringForKey("avConhecimento")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

