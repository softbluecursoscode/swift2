//
//  ViewController.swift
//  Configuracoes
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var labelServidor : UILabel!
    @IBOutlet weak var labelPorta : UILabel!
    @IBOutlet weak var labelEmail : UILabel!
    @IBOutlet weak var labelSenha : UILabel!
    @IBOutlet weak var labelAutoLogin : UILabel!
    @IBOutlet weak var labelModo : UILabel!
    @IBOutlet weak var labelEspaco : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.getSettingsValue()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func actionToUpdate()
    {
        self.getSettingsValue()
    }
    
    func getSettingsValue()
    {
        var myUserDefaults = NSUserDefaults.standardUserDefaults()
        
        labelServidor.text = myUserDefaults.stringForKey("sbServidor")
        labelPorta.text = myUserDefaults.stringForKey("sbPorta")
        labelEmail.text = myUserDefaults.stringForKey("sbEmail")
        labelSenha.text = myUserDefaults.stringForKey("sbSenha")
        
        if(myUserDefaults.boolForKey("sbAutoLogin") == true)
        {
            labelAutoLogin.text = "Sim"
        }
        else
        {
            labelAutoLogin.text = "Não"
        }
        
        labelModo.text = myUserDefaults.stringForKey("sbModo")
        labelEspaco.text = myUserDefaults.stringForKey("sbEspaco")
    }

}

