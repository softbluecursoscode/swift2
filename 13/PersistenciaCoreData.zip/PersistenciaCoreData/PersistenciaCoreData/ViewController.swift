//
//  ViewController.swift
//  PersistenciaCoreData
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var fieldFirstName : UITextField!
    @IBOutlet weak var fieldLastName : UITextField!
    @IBOutlet weak var fieldEmail : UITextField!
    
    var appDelegate : AppDelegate!
    var managedContext : NSManagedObjectContext!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        managedContext = appDelegate.managedObjectContext!
        
        var myFetchRequest : NSFetchRequest = NSFetchRequest(entityName: "Usuario")
        var myError : NSError?
        var myFetchedResults : [NSManagedObject] = managedContext.executeFetchRequest(myFetchRequest, error: &myError) as [NSManagedObject]
        
        if(!myFetchedResults.isEmpty)
        {
            var user : NSManagedObject = myFetchedResults[0]
            
            fieldFirstName.text = user.valueForKey("firstName") as String
            fieldLastName.text = user.valueForKey("lastName") as String
            fieldEmail.text = user.valueForKey("email") as String
            
            managedContext.deleteObject(user)
        }
        
        var myObject : UIApplication = UIApplication.sharedApplication()
        var mySelector : Selector = NSSelectorFromString("salvarDados:")
        
        NSNotificationCenter.defaultCenter().addObserver(self,
            selector: mySelector,
            name: UIApplicationWillResignActiveNotification,
            object: myObject)
    }
    
    func salvarDados(notification: NSNotification) -> Void
    {
        var myEntity : NSEntityDescription? = NSEntityDescription.entityForName("Usuario", inManagedObjectContext: managedContext)
        
        var user : NSManagedObject = NSManagedObject(entity: myEntity!, insertIntoManagedObjectContext: managedContext)
        
        user.setValue(fieldFirstName.text, forKey: "firstName")
        user.setValue(fieldLastName.text, forKey: "lastName")
        user.setValue(fieldEmail.text, forKey: "email")
        
        var myError : NSError?
        
        if(managedContext.save(&myError))
        {
            
        }
        else
        {
            // myAlert.message = "Erro: \(myError) \(myError?.userInfo)"
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }



}

