//
//  ViewController.swift
//  EXPersistencia01
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myLabel : UILabel!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getFilepath() -> String
    {
        var userDomainPaths : NSArray = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        
        var filepath : String = userDomainPaths.objectAtIndex(0) as String
        
        return "\(filepath)myFile.plist"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var filepath : String = self.getFilepath()
        
        // Verifica existência do arquivo e, caso exista, inicializa a label com o valor armazenado
        if(NSFileManager.defaultManager().fileExistsAtPath(filepath))
        {
            var array : NSArray = NSArray(contentsOfFile: filepath)!
            myLabel.text = array.objectAtIndex(0) as? String
        }
        
        // Caso não exista, é necessário inicializar a label com o valor 0
        else
        {
            myLabel.text = "0"
        }
        
        // Atualiza o contador
        // O método "toInt()" converte um objeto do tipo STRING para INT
        var contador : Int = myLabel.text!.toInt()!
        contador++
        myLabel.text = "\(contador)"
        
        // Já salva no arquivo pois a informação não depende do usuário para ser atualizada, podendo ser salva já
        var array : NSMutableArray = NSMutableArray()
        array.addObject(myLabel.text!)
        array.writeToFile(filepath, atomically: true)
    }
    
}





