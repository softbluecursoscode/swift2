//
//  ViewController.swift
//  EXPersistencia02
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var fieldMarca : UITextField!
    @IBOutlet weak var fieldModelo : UITextField!
    @IBOutlet weak var fieldIsEletrico : UISwitch!
    @IBOutlet weak var fieldNumeroDeCordas : UISlider!
    
    @IBOutlet weak var labelSliderValue : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getFilepath() -> String
    {
        var userDomainPaths : NSArray = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        
        var filepath : String = userDomainPaths.objectAtIndex(0) as String
        
        return "\(filepath)encodedViolao"
    }
    
    @IBAction func textFieldReturn(sender: AnyObject)
    {
        sender.resignFirstResponder()
    }
    
    @IBAction func sliderValueChanged()
    {
        var sliderFloatValue : Float!
        sliderFloatValue = fieldNumeroDeCordas?.value
        
        var sliderIntValue : Int
        sliderIntValue = Int(sliderFloatValue)
        
        var newLabelText : String
        newLabelText = "\(sliderIntValue)"
        
        labelSliderValue?.text = newLabelText
    }
    
    @IBAction func salvar()
    {
        var myViolao : Violao = Violao()
        
        myViolao.marca = fieldMarca.text
        myViolao.modelo = fieldModelo.text
        
        if(fieldIsEletrico.on == true)
        {
            myViolao.isEletrico = true
        }
        else
        {
            myViolao.isEletrico = false
        }
        
        myViolao.numeroDeCordas = fieldNumeroDeCordas.value
        
        var data : NSMutableData = NSMutableData()
        var archiver : NSKeyedArchiver = NSKeyedArchiver(forWritingWithMutableData: data)
        archiver.encodeObject(myViolao, forKey: "MeuObjeto")
        archiver.finishEncoding()
        
        data.writeToFile(self.getFilepath(), atomically: true)
    }
    
    @IBAction func carregar()
    {
        var filepath : String = self.getFilepath()
        
        // Verifica existência do arquivo com os dados para leitura
        if(NSFileManager.defaultManager().fileExistsAtPath(filepath))
        {
            var data : NSData = NSMutableData(contentsOfFile: filepath)!
            
            // Prepara o objeto para ser desserializado
            var unarchiver : NSKeyedUnarchiver = NSKeyedUnarchiver(forReadingWithData: data)
            
            var loadedViolao : Violao = unarchiver.decodeObjectForKey("MeuObjeto") as Violao
            
            unarchiver.finishDecoding()
            
            // Exibe os textos por meio da propriedade TEXT dos UITextFields
            fieldMarca.text = loadedViolao.marca
            fieldModelo.text = loadedViolao.modelo
            
            // Atualiza o Switch por meio da propriedade ON do UISwitch
            fieldIsEletrico.on = loadedViolao.isEletrico
            
            // Atualiza o Slider por meio da propriedade VALUE de UISlider
            fieldNumeroDeCordas.value = loadedViolao.numeroDeCordas
            
            // Atualiza a label do slider por meio da Action já existente
            sliderValueChanged()
        }
    }
    
    @IBAction func resetar()
    {
        // Exibe os textos por meio da propriedade TEXT dos UITextFields
        fieldMarca.text = ""
        fieldModelo.text = ""
        
        // Atualiza o Switch por meio da propriedade ON do UISwitch
        fieldIsEletrico.on = true
        
        // Atualiza o Slider por meio da propriedade VALUE de UISlider
        fieldNumeroDeCordas.value = 6
        
        // Atualiza a label do slider por meio da Action já existente
        sliderValueChanged()
    }
    
    /*

    - (IBAction) salvar
    {
    // Método de salvar: empacota o objeto, tratando o Switch e o Slider de forma exclusiva
    
    InstrumentoMusical *instrumento = [[InstrumentoMusical alloc] init];
    instrumento.marca = fieldMarca.text;
    instrumento.modelo = fieldModelo.text;
    instrumento.isEletrico = fieldIsEletrico.on ? @"TRUE" : @"FALSE";
    instrumento.numeroDeCordas = labelAuxSlider.text;
    
    // Empacotamento e criação/atualização do arquivo
    
    NSMutableData *data = [[NSMutableData alloc] init];
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
    [archiver encodeObject:instrumento forKey:@"Data"];
    [archiver finishEncoding];
    [data writeToFile:[self getFilepath] atomically:TRUE];
    }
    
    - (IBAction) carregar
    {
    NSString *filepath = [self getFilepath];
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:filepath]) {
    
    // Havendo alguma versão salva, a mesma é carregada neste método de desempacotamento
    NSData *data = [[NSMutableData alloc] initWithContentsOfFile:[self getFilepath]];
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
    
    InstrumentoMusical *instrumento = [unarchiver decodeObjectForKey:@"Data"];
    [unarchiver finishDecoding];
    
    // População dos campos do formulário, tratando Switch e Slider de forma apropriada
    
    fieldMarca.text = instrumento.marca;
    fieldModelo.text = instrumento.modelo;
    fieldIsEletrico.on = [instrumento.isEletrico isEqualToString:@"TRUE"] ? TRUE : FALSE;
    fieldNumeroDeCordas.value = [instrumento.numeroDeCordas floatValue];
    labelAuxSlider.text = [[NSString alloc] initWithFormat:@"%d", [instrumento.numeroDeCordas intValue]];
    }
    }
    
    - (IBAction) resetar
    {
    // Reseta os campos para seus valores iniciais, sem alterar o arquivo
    
    fieldMarca.text = @"";
    fieldModelo.text = @"";
    fieldIsEletrico.on = true;
    fieldNumeroDeCordas.value = (float)6;
    labelAuxSlider.text = @"6";
    }
*/


}

