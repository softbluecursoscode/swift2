//
//  Violao.swift
//  EXPersistencia02
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class Violao: NSObject, NSCoding, NSCopying
{
    var marca : String!
    var modelo : String!
    var isEletrico : Bool!
    var numeroDeCordas : Float!
    
    override init()
    {
        
    }
    
    // Método de serialização definido pelo protocolo NSCoding
    func encodeWithCoder(aCoder: NSCoder)
    {
        aCoder.encodeObject(marca, forKey: "mar")
        aCoder.encodeObject(modelo, forKey: "mod")
        aCoder.encodeObject(isEletrico, forKey: "ele")
        aCoder.encodeObject(numeroDeCordas, forKey: "cor")
    }

    // Método de desserialização definido pelo protocolo NSCoding
    required init(coder aDecoder: NSCoder) //aqui tinha NSCoder!
    {
        marca = aDecoder.decodeObjectForKey("mar") as String
        modelo = aDecoder.decodeObjectForKey("mod") as String
        isEletrico = aDecoder.decodeObjectForKey("ele") as Bool
        numeroDeCordas = aDecoder.decodeObjectForKey("cor") as Float
    }

    // Método de cópia definido pelo protocolo NSCopying
    func copyWithZone(zone: NSZone) -> AnyObject
    {
        var myViolao : Violao = Violao()
        
        myViolao.marca = self.marca
        myViolao.modelo = self.modelo
        myViolao.isEletrico = self.isEletrico
        myViolao.numeroDeCordas = self.numeroDeCordas
        
        return myViolao
    }
}

