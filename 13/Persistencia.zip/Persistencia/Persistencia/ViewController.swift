//
//  ViewController.swift
//  Persistencia
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var fieldFirstName : UITextField!
    @IBOutlet weak var fieldLastName : UITextField!
    @IBOutlet weak var fieldEmail : UITextField!
    
    func getFilepath() -> String
    {
        var userDomainPaths : NSArray = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        
        var filepath : String = userDomainPaths.objectAtIndex(0) as String
        
        return "\(filepath)myFile.plist"
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var filepath : String = self.getFilepath()
        
        if(NSFileManager.defaultManager().fileExistsAtPath(filepath))
        {
            var array : NSArray = NSArray(contentsOfFile: filepath)!
            
            fieldFirstName.text = array.objectAtIndex(0) as String
            fieldLastName.text = array.objectAtIndex(1) as String
            fieldEmail.text = array.objectAtIndex(2) as String
        }
        
        var myObject : UIApplication = UIApplication.sharedApplication()
        
        var mySelector : Selector = NSSelectorFromString("applicationWillResignActiveNotificationFunctions:")
        
        NSNotificationCenter.defaultCenter().addObserver(self,
            selector: mySelector,
            name: UIApplicationWillResignActiveNotification,
            object: myObject)
    }
    
    func applicationWillResignActiveNotificationFunctions(notification: NSNotification) -> Void
    {
        var array : NSMutableArray = NSMutableArray()
        array.addObject(fieldFirstName.text)
        array.addObject(fieldLastName.text)
        array.addObject(fieldEmail.text)
        
        var filepath : String = self.getFilepath()
        
        array.writeToFile(filepath, atomically: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

