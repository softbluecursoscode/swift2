//
//  UserSample.swift
//  PersistenciaObjeto
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class UserSample: NSObject, NSCoding, NSCopying
{
    var firstName : String!
    var lastName : String!
    var email : String!
    
    func encodeWithCoder(aCoder: NSCoder)
    {
        aCoder.encodeObject(firstName, forKey: "fnKey")
        aCoder.encodeObject(lastName, forKey: "lnKey")
        aCoder.encodeObject(email, forKey: "eKey")
    }
    
    override init()
    {
        
    }
    
    required init(coder aDecoder: NSCoder)
    {
        firstName = aDecoder.decodeObjectForKey("fnKey") as String
        lastName = aDecoder.decodeObjectForKey("lnKey") as String
        email = aDecoder.decodeObjectForKey("eKey") as String
    }
    
    func copyWithZone(zone: NSZone) -> AnyObject
    {
        var myUserSample : UserSample = UserSample()
        
        myUserSample.firstName = self.firstName
        myUserSample.lastName = self.lastName
        myUserSample.email = self.email
        
        return myUserSample
    }
}
