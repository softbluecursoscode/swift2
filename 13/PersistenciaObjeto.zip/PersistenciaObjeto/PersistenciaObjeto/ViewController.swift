//
//  ViewController.swift
//  PersistenciaObjeto
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var fieldFirstName : UITextField!
    @IBOutlet weak var fieldLastName : UITextField!
    @IBOutlet weak var fieldEmail : UITextField!
    
    func getFilepath() -> String
    {
        var userDomainPaths : NSArray = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        
        var filepath : String = userDomainPaths.objectAtIndex(0) as String
        
        return "\(filepath)encodedObjectFile"
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var filepath : String = self.getFilepath()
        
        if(NSFileManager.defaultManager().fileExistsAtPath(filepath))
        {
            var data : NSData = NSMutableData(contentsOfFile: filepath)!
            
            var unarchiver : NSKeyedUnarchiver = NSKeyedUnarchiver(forReadingWithData: data)
            
            var userSample : UserSample = unarchiver.decodeObjectForKey("MeuObjeto") as UserSample
            
            unarchiver.finishDecoding()
            
            fieldFirstName.text = userSample.firstName
            fieldLastName.text = userSample.lastName
            fieldEmail.text = userSample.email
        }
        
        var myObject : UIApplication = UIApplication.sharedApplication()
        
        var mySelector : Selector = NSSelectorFromString("applicationWillResignActiveNotificationFunctions:")
        
        NSNotificationCenter.defaultCenter().addObserver(self,
            selector: mySelector,
            name: UIApplicationWillResignActiveNotification,
            object: myObject)
    }
    
    func applicationWillResignActiveNotificationFunctions(notification: NSNotification) -> Void
    {
        var userSample : UserSample = UserSample()
        
        userSample.firstName = fieldFirstName.text
        userSample.lastName = fieldLastName.text
        userSample.email = fieldEmail.text
        
        var data : NSMutableData = NSMutableData()
        var archiver : NSKeyedArchiver = NSKeyedArchiver(forWritingWithMutableData: data)
        archiver.encodeObject(userSample, forKey: "MeuObjeto")
        archiver.finishEncoding()
        
        data.writeToFile(self.getFilepath(), atomically: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

