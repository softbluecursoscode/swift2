//
//  ViewController.swift
//  Camera
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit
import MediaPlayer
import MobileCoreServices

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var myImageView : UIImageView!
    @IBOutlet weak var myButton : UIButton!
    
    var myImageFrame : CGRect!
    var myLastMediaType : String!
    var myMovieURL : NSURL!
    var myImage : UIImage!
    var myMoviePlayerController : MPMoviePlayerController!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        if(UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera) == false)
        {
            myButton.hidden = true
        }
        
        myImageFrame = myImageView.frame
    }
    
    @IBAction func getMediaRealTime()
    {
        self.getMediaFromControllerSourceType(UIImagePickerControllerSourceType.Camera)
    }
    
    @IBAction func getMediaFromLibrary()
    {
        self.getMediaFromControllerSourceType(UIImagePickerControllerSourceType.PhotoLibrary)
    }
    
    func getMediaFromControllerSourceType(sourceType: UIImagePickerControllerSourceType) -> Void
    {
        var arrayMediaTypes : NSArray = UIImagePickerController.availableMediaTypesForSourceType(sourceType)!
        
        if(arrayMediaTypes.count > 0 && UIImagePickerController.isSourceTypeAvailable(sourceType))
        {
            var imagePickerController : UIImagePickerController = UIImagePickerController()
            imagePickerController.sourceType = sourceType
            imagePickerController.allowsEditing = true
            imagePickerController.mediaTypes = arrayMediaTypes as [AnyObject]
            imagePickerController.delegate = self
            
            self.presentViewController(imagePickerController, animated: true, completion: nil)
        }
        else
        {
            var myAlert : UIAlertView = UIAlertView()
            myAlert.title = "Erro"
            myAlert.message = "Não foi possível utilizar esta opção"
            myAlert.addButtonWithTitle("OK")
            myAlert.show()
        }
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController)
    {
        picker.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [NSObject : AnyObject])
    {
        myLastMediaType = info[UIImagePickerControllerMediaType] as! String
        
        if(myLastMediaType as String == kUTTypeMovie as String)
        {
            myMovieURL = info[UIImagePickerControllerMediaURL] as! NSURL
        }
        else if(myLastMediaType as String == kUTTypeImage as String)
        {
            myImage = info[UIImagePickerControllerEditedImage] as! UIImage
        }
        
        picker.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func updateDisplay() -> Void
    {
        if(myLastMediaType == nil)
        {
            return
        }
        
        if(myLastMediaType as String == kUTTypeMovie as String)
        {
            if(myMoviePlayerController != nil)
            {
                myMoviePlayerController.view.removeFromSuperview()
            }
            
            myMoviePlayerController = MPMoviePlayerController(contentURL: myMovieURL)
            myMoviePlayerController.view.frame = myImageFrame
            myMoviePlayerController.view.clipsToBounds = true
            self.view.addSubview(myMoviePlayerController.view)
            
            myMoviePlayerController.play()
            myImageView.hidden = true
        }
        else if(myLastMediaType as String == kUTTypeImage as String)
        {
            myImageView.image = myImage
            myImageView.hidden = false
            
            if(myMoviePlayerController != nil)
            {
                myMoviePlayerController.view.hidden = true
            }
        }
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        self.updateDisplay()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

