//
//  ViewController.swift
//  Customizando
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // Icon.png (57x57)
    // Icon@2x.png (114x114)
    // Icon-72.png (72x72)
    // Icon-72@2x.png (144x144)

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

