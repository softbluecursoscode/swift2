//
//  ViewController.swift
//  CocoaTouch
//
//  Created by Andre Milani on 11/12/14.
//  Copyright (c) 2014 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myLabel : UILabel?
    @IBOutlet weak var myButtonOne : UIButton?
    @IBOutlet weak var myButtonTwo : UIButton?
    
    // Caro aluno, não esqueça de conectar suas IBOutlets e IBActions na interface gráfica
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func executeSomeTask(sender: UIButton)
    {
        var quemInvocou : String = sender.titleForState(UIControlState.Normal)!
        var novoTexto : String = "Botão \(quemInvocou) utilizado!"
        
        myLabel?.text = novoTexto
    }


}

