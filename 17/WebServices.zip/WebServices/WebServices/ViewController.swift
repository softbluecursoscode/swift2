//
//  ViewController.swift
//  WebServices
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

// Documentação da Apple
// https://www.apple.com/itunes/affiliates/resources/documentation/itunes-store-web-service-search-api.html

import UIKit

class ViewController: UIViewController {
    
    var data : NSMutableData = NSMutableData()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func searchItunesFor(buscarPor: String)
    {
        var buscarPorFormatado = buscarPor.stringByReplacingOccurrencesOfString(" ", withString: "+", options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil)
        
        var buscarPorFinal : String = buscarPorFormatado.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding)!
        
        var urlWebService = "https://itunes.apple.com/search?term=\(buscarPorFinal)&media=music"
        
        var url : NSURL = NSURL(string: urlWebService)!
        var request : NSURLRequest = NSURLRequest(URL: url)
        var connection : NSURLConnection = NSURLConnection(request: request, delegate: self, startImmediately: false)!
        
        connection.start()
    }
    
    func connection(connection: NSURLConnection!, didFailWithError error: NSError!)
    {
        println("Falha na conexão: \(error.localizedDescription)")
    }
    
    func connection(didReceiveResponse: NSURLConnection!, didReceiveResponse response: NSURLResponse!)
    {
        self.data = NSMutableData()
    }
    
    func connection(connection: NSURLConnection!, didReceiveData data: NSData!)
    {
        self.data.appendData(data)
    }
    
    func connectionDidFinishLoading(connection: NSURLConnection!)
    {
        var jsonData : NSDictionary = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers, error: nil) as NSDictionary
        
        //println(jsonData)
        
        //var i : Int = jsonData.objectForKey("resultCount") as Int
        var i : Int = jsonData["resultCount"] as Int
        
        var resultados : NSArray = jsonData["results"] as NSArray
        
        for x in 0 ... i-1
        {
            var resultado : NSDictionary = resultados[x] as NSDictionary
            
            var nomeDaMusica : String = resultado["trackName"] as String
            var preco : Double = resultado["trackPrice"] as Double
            
            var buffer : String = "\(nomeDaMusica) por U$ \(preco)"
            println(buffer)
        }
    }
    
    @IBAction func callWebService()
    {
        self.searchItunesFor("Metallica")
    }
 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}

