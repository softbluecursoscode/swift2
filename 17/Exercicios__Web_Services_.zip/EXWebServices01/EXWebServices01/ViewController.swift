//
//  ViewController.swift
//  WebServices
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

// Documentação da Apple
// https://www.apple.com/itunes/affiliates/resources/documentation/itunes-store-web-service-search-api.html

import UIKit

class ViewController: UIViewController {
    
    // Campo para capturar o termo a ser buscado
    @IBOutlet weak var myTextField : UITextField!
    
    // Tableview para poder invocar seu método de atualização
    @IBOutlet weak var myTableView : UITableView!
    
    // Estrutura para tratamento de dados recebidos pelo Web Service
    var data : NSMutableData = NSMutableData()
    
    // Arrays que serão utilizados pelo TableView
    var filmes : NSMutableArray = NSMutableArray()
    var diretores : NSMutableArray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func searchItunesFor(buscarPor: String)
    {
        var buscarPorFormatado = buscarPor.stringByReplacingOccurrencesOfString(" ", withString: "+", options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil)
        
        var buscarPorFinal : String = buscarPorFormatado.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding)!
        
        var urlWebService = "https://itunes.apple.com/search?term=\(buscarPorFinal)&media=movie"
        
        var url : NSURL = NSURL(string: urlWebService)!
        var request : NSURLRequest = NSURLRequest(URL: url)
        var connection : NSURLConnection = NSURLConnection(request: request, delegate: self, startImmediately: false)!
        
        connection.start()
    }
    
    func connection(connection: NSURLConnection!, didFailWithError error: NSError!)
    {
        println("Falha na conexão: \(error.localizedDescription)")
    }
    
    func connection(didReceiveResponse: NSURLConnection!, didReceiveResponse response: NSURLResponse!)
    {
        self.data = NSMutableData()
    }
    
    func connection(connection: NSURLConnection!, didReceiveData data: NSData!)
    {
        self.data.appendData(data)
    }
    
    func connectionDidFinishLoading(connection: NSURLConnection!)
    {
        var jsonData : NSDictionary = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers, error: nil) as NSDictionary

        var i : Int = jsonData["resultCount"] as Int
        
        var resultados : NSArray = jsonData["results"] as NSArray
        
        for x in 0 ... i-1
        {
            var resultado : NSDictionary = resultados[x] as NSDictionary
            
            var nomeDoFilme : String = resultado["trackName"] as String
            var diretor : String = resultado["artistName"] as String
            
            // Popula os arrays do table view
            filmes.addObject(nomeDoFilme)
            diretores.addObject(diretor)
        }
        
        // Atualiza o table view agora que os arrays foram populados
        myTableView.reloadData()
    }
    
    // Trata o fechamento do teclado
    @IBAction func textFieldReturn(sender: AnyObject)
    {
        sender.resignFirstResponder()
    }
    
    // Action que inicia a busca
    @IBAction func callWebService()
    {
        var busca : String = myTextField.text
        self.searchItunesFor(busca)
    }
    
    // Método 1 do tableview
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.filmes.count
    }
    
    // Método 2 do tableview
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var myId : String = "exemplo"
        
        var cell : UITableViewCell? = tableView.dequeueReusableCellWithIdentifier(myId) as? UITableViewCell
        
        if(cell == nil)
        {
            cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: myId)
        }
        
        cell?.textLabel?.text = filmes.objectAtIndex(indexPath.row) as? String

        return cell!
    }
    
    // Método 3 do tableview
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        var myMessage : String = diretores.objectAtIndex(indexPath.row) as String
        
        let myAlert = UIAlertView()
        myAlert.title = "Diretor:"
        myAlert.message = myMessage
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

