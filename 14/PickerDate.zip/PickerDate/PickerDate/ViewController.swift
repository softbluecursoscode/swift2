//
//  ViewController.swift
//  PickerDate
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myPickerDate : UIDatePicker!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showInfo()
    {
        var myDate : NSDate = myPickerDate.date
        
        var myAlert = UIAlertView()
        myAlert.title = "Picker Date"
        myAlert.message = "A data é \(myDate)"
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }

}

