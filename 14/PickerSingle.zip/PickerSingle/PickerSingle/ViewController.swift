//
//  ViewController.swift
//  PickerSingle
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var myPickerSingle : UIPickerView!
    var myPickerDataSource : NSArray!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.myPickerDataSource = NSArray(objects: "Cerveja", "Drink", "Refrigerante", "Caipirinha", "Suco")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return myPickerDataSource.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String!
    {
        return myPickerDataSource.objectAtIndex(row) as String
    }

    @IBAction func showInfo()
    {
        var myRow : Int = myPickerSingle.selectedRowInComponent(0)
        var myValue : String = myPickerDataSource.objectAtIndex(myRow) as String
        
        var myAlert = UIAlertView()
        myAlert.title = "Picker Single"
        myAlert.message = myValue
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }

}

