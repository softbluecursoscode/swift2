//
//  ViewController.swift
//  PickerDouble
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var myPickerDouble : UIPickerView!
    var myPickerDataSourceTypes : NSArray!
    var myPickerDataSourceFlavours : NSArray!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.myPickerDataSourceTypes = NSArray(objects: "Cerveja", "Drink", "Refrigerante", "Caipirinha", "Suco")
        
        self.myPickerDataSourceFlavours = NSArray(objects:
            NSArray(objects: "Clara", "Escura"),
            NSArray(objects: "Alexander", "Pina Colada"),
            NSArray(objects: "Cola", "Limão", "Laranja"),
            NSArray(objects: "Limão", "Abacaxi", "Morango", "Maracujá", "Tropical"),
            NSArray(objects: "Laranja") )
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int
    {
        return 2
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if(component == 0)
        {
            return myPickerDataSourceTypes.count
        }
        else
        {
            var myRow : Int = myPickerDouble.selectedRowInComponent(0)
            var myFlavours : NSArray = myPickerDataSourceFlavours.objectAtIndex(myRow) as NSArray
            return myFlavours.count
        }
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String!
    {
        if(component == 0)
        {
            return myPickerDataSourceTypes.objectAtIndex(row) as String
        }
        else
        {
            var myRow : Int = myPickerDouble.selectedRowInComponent(0)
            var myFlavours : NSArray = myPickerDataSourceFlavours.objectAtIndex(myRow) as NSArray
            return myFlavours.objectAtIndex(row) as String
        }
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        if(component == 0)
        {
            myPickerDouble.reloadComponent(1)
            myPickerDouble.selectRow(0, inComponent: 1, animated: true)
        }
    }
    
    @IBAction func showInfo()
    {
        var myRow : Int = myPickerDouble.selectedRowInComponent(0)
        var myValue : String = myPickerDataSourceTypes.objectAtIndex(myRow) as String
        
        var myRowFlavour : Int = myPickerDouble.selectedRowInComponent(1)
        var myValueFlavours : NSArray = myPickerDataSourceFlavours.objectAtIndex(myRow) as NSArray
        var myValueFlavour : String = myValueFlavours.objectAtIndex(myRowFlavour) as String
        
        var myAlert = UIAlertView()
        myAlert.title = "Picker Double"
        myAlert.message = "\(myValue) \(myValueFlavour)"
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


}

