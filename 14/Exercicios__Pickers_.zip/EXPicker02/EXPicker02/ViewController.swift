//
//  ViewController.swift
//  GuiaPickerSingle
//
//  Created by Andre Milani on 16/12/14.
//  Copyright (c) 2014 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var myPickerDouble : UIPickerView!
    
    var dicionario : NSDictionary = NSDictionary()
    var categorias : NSMutableArray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Carrega o arquivo
        var filepath : String = NSBundle.mainBundle().pathForResource("pickerLista", ofType: "plist")!
        
        // Cria um dicionário baseado nos elementos do arquivo
        dicionario = NSDictionary(contentsOfFile: filepath)!
        
        // Cria um array com as categorias existentes no arquivo
        // Este array já é o array de dados da primeira coluna do picker do exercício
        categorias = NSMutableArray(array: dicionario.allKeys);
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int
    {
        return 2
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if(component == 0)
        {
            return categorias.count
        }
        else
        {
            // Captura o array da categoria em questão na coluna 1 para contabilizar seus elementos
            // Para isso é necessário descobrir primeiro qual é o valor do elemento selecionado na coluna 1
            var linhaSelecionadaColuna1 : Int = myPickerDouble.selectedRowInComponent(0)
            var elementoSelecionadoColuna1 : String = categorias.objectAtIndex(linhaSelecionadaColuna1) as String

            // E baseado nele, buscar o array correspondente, pois cada categoria é uma chave de acesso no dicionário
            var elementos : NSArray = dicionario.objectForKey(elementoSelecionadoColuna1) as NSArray
            
            return elementos.count
        }
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String!
    {
        if(component == 0)
        {
            return categorias.objectAtIndex(row) as String
        }
        else
        {
            // Captura o array da categoria em questão na coluna 1 do picker
            var linhaSelecionadaColuna1 : Int = myPickerDouble.selectedRowInComponent(0)
            var elementoSelecionadoColuna1 : String = categorias.objectAtIndex(linhaSelecionadaColuna1) as String
            
            var elementos : NSArray = dicionario.objectForKey(elementoSelecionadoColuna1) as NSArray
            
            // ...e acessa sua posição numérica relativa a segunda coluna do picker
            return elementos.objectAtIndex(row) as String
        }
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        if(component == 0)
        {
            myPickerDouble.selectRow(0, inComponent: 1, animated: true)
            myPickerDouble.reloadComponent(1)
        }
    }
    
    @IBAction func showInfo()
    {
        // Captura o valor do componente 1
        var linhaColuna1 : Int = myPickerDouble.selectedRowInComponent(0)
        var valorColuna1 : String = categorias.objectAtIndex(linhaColuna1) as String
        
        // Captura o valor do componente 2
        // Começa capturando o array de elementos para a categoria em questão selecionada na coluna 1
        var elementos : NSArray = dicionario.objectForKey(valorColuna1) as NSArray
        
        // Com esse array de elementos em mãos, basta saber qual foi a linha selecionada no picker na coluna 2
        var linhaColuna2 : Int = myPickerDouble.selectedRowInComponent(1)
        
        // Portanto:
        var valorColuna2 : String = elementos.objectAtIndex(linhaColuna2) as String
        
        // Cria a mensagem
        var myAlert = UIAlertView()
        myAlert.title = "Combinação"
        myAlert.message = "\(valorColuna1): \(valorColuna2)"
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
}

