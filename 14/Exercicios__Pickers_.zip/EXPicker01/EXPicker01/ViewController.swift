//
//  ViewController.swift
//  GuiaPickerSingle
//
//  Created by Andre Milani on 16/12/14.
//  Copyright (c) 2014 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var myPickerDouble : UIPickerView!
    var myPickerDataSourceFoods : NSArray!
    var myPickerDataSourceDrinks : NSArray!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.myPickerDataSourceFoods = NSArray(objects: "X-Salada", "X-Burguer", "X-Bacon", "X-Egg", "X-Tudo")
        
        self.myPickerDataSourceDrinks = NSArray(objects: "Coca-cola", "Pepsi", "Fanta", "Sprite", "Água")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showInfo()
    {
        // Captura o valor do componente 1
        
        var myRowFoods : Int = myPickerDouble.selectedRowInComponent(0)
        var myValueFoods : String = myPickerDataSourceFoods.objectAtIndex(myRowFoods) as String
        
        // Captura o valor do componente 2
        
        var myRowDrinks : Int = myPickerDouble.selectedRowInComponent(1)
        var myValueDrinks : String = myPickerDataSourceDrinks.objectAtIndex(myRowDrinks) as String
        
        // Cria a mensagem
        
        var myAlert = UIAlertView()
        myAlert.title = "Pedido"
        myAlert.message = "\(myValueFoods) com \(myValueDrinks)"
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int
    {
        return 2
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if(component == 0)
        {
            return myPickerDataSourceFoods.count
        }
        else
        {
            return myPickerDataSourceDrinks.count
        }
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String!
    {
        if(component == 0)
        {
            return myPickerDataSourceFoods.objectAtIndex(row) as String
        }
        else
        {
            return myPickerDataSourceDrinks.objectAtIndex(row) as String
        }
    }
}

