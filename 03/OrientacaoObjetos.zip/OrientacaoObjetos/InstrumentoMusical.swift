//
//  InstrumentoMusical.swift
//  OrientacaoObjetos
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class InstrumentoMusical : Guardavel {
    
    private var percussao : Bool
    private var volume : Int
    
    init(percussao: Bool, volume: Int)
    {
        self.percussao = percussao
        self.volume = volume
    }
    
    func tocar() -> String
    {
        return "Som de Instrumento Musical"
    }
    
    func getVolume() -> Int
    {
        return self.volume
    }
    
    func isPercussao() -> Bool
    {
        return self.percussao
    }
    
    func guardar() -> String
    {
        return "Instrumento Musical guardado"
    }
   
}
