//
//  Guitarra.swift
//  OrientacaoObjetos
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class Guitarra : InstrumentoMusical {
   
    private var numeroDeCordas : Int
    
    init(numeroDeCordas: Int, percussao: Bool, volume: Int)
    {
        self.numeroDeCordas = numeroDeCordas
        super.init(percussao: percussao, volume: volume)
    }
    
    func getNumeroDeCordas() -> Int
    {
        return self.numeroDeCordas
    }
    
    override func tocar() -> String
    {
        return "Som de GUITARRA! Rock!"
    }
    
    override func guardar() -> String
    {
        return "Em case de guitarra"
    }
    
}
