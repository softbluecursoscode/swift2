//
//  Carro.swift
//  OrientacaoObjetos
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class Carro {
   
    private var velocidade : Int
    private var cor : String
    
    init(velocidade: Int, cor: String)
    {
        self.velocidade = velocidade
        self.cor = cor
    }
    
    func acelerar() -> Void
    {
        self.velocidade++
    }
    
    func acelerar(quanto: Int) -> Void
    {
        self.velocidade += quanto
    }
    
    func frear() -> Void
    {
        self.velocidade--
    }
    
    func setVelocidade(novaVelocidade: Int) -> Void
    {
        if(novaVelocidade > 120)
        {
            self.velocidade = 120
        }
        else
        {
            self.velocidade = novaVelocidade
        }
    }
    
    func getVelocidade() -> Int
    {
        return self.velocidade
    }
    
    func setCor(novaCor: String) -> Void
    {
        self.cor = novaCor
    }
    
    func getCor() -> String
    {
        return self.cor
    }
    
}
