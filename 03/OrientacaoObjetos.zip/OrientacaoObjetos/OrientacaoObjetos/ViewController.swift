//
//  ViewController.swift
//  OrientacaoObjetos
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var myBuffer : String
        
        // CLASSE CARRO
        var myCar : Carro = Carro(velocidade: 98, cor: "Vermelha")
        myCar.acelerar()
        myCar.acelerar()
        myCar.frear()
        myCar.acelerar(10) // Sobrecarga de método
        myBuffer = "Velocidade: \(myCar.getVelocidade())"
        
        // CLASSE INSTRUMENTO MUSICAL
        var myInstrumento : InstrumentoMusical = InstrumentoMusical(percussao: true, volume: 100)
        myBuffer = "A bateria tem volume \(myInstrumento.getVolume())"
        
        // CLASSE GUITARRA
        var myGuitarra : Guitarra = Guitarra(numeroDeCordas: 6, percussao: false, volume: 50)
        myBuffer = "A guitarra de \(myGuitarra.getNumeroDeCordas()) cordas tem volume \(myGuitarra.getVolume())"
        myBuffer = "Som de guitarra: \(myGuitarra.tocar())" // Sobrescrita de método
        
        // PROTOCOLO
        myBuffer = "Guardar guitarra: \(myGuitarra.guardar())"

        // ALERTA
        let myAlert = UIAlertView()
        myAlert.title = "Alerta"
        myAlert.message = myBuffer
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

