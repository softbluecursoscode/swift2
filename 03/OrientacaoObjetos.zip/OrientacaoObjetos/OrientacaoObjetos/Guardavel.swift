//
//  Guardavel.swift
//  OrientacaoObjetos
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

protocol Guardavel {
   
    func guardar() -> String
    
}
