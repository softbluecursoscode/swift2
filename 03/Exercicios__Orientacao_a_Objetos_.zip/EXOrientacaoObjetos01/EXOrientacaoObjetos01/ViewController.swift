//
//  ViewController.swift
//  EXOrientacaoObjetos01
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var circulo : Circulo = Circulo(raio: 2.5)
        var losangulo : Losangulo = Losangulo(diagonalMenor: 1.5, diagonalMaior: 3)
        var quadrado : Quadrado = Quadrado(comprimento: 4, altura: 2)
        
        var ac : Float = circulo.calculoDaArea()
        var al : Float = losangulo.calculoDaArea()
        var aq : Float = quadrado.calculoDaArea()

        // O caracter de escape "\n" é utilizado para quebrar linha
        
        var buffer : String = "Área do círculo: \(ac)\nÁrea do losângulo: \(al)\nÁrea do quadrado: \(aq)"
        
        var myAlert : UIAlertView = UIAlertView()
        myAlert.title = "Resultado"
        myAlert.message = buffer
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

