//
//  Quadrado.swift
//  EXOrientacaoObjetos01
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class Quadrado: FormaGeometrica
{
    var comprimento : Float
    var altura : Float
    
    init(comprimento: Float, altura: Float)
    {
        self.comprimento = comprimento
        self.altura = altura
    }
    
    func calculoDaArea() -> Float
    {
        return comprimento * altura
    }
}
