//
//  Circulo.swift
//  EXOrientacaoObjetos01
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class Circulo: FormaGeometrica
{
    var raio : Float
    
    init(raio: Float)
    {
        self.raio = raio
    }
    
    func calculoDaArea() -> Float
    {
        return 3.14 * (raio * raio)
    }
}
