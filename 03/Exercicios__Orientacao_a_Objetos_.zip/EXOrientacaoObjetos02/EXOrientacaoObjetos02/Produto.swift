//
//  Produto.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class Produto: ShowInfo
{
    private var estilo : String!
    private var codigo : String!
    
    init(estilo: String, codigo: String)
    {
        self.estilo = estilo
        self.codigo = codigo
    }
    
    func getCodigo() -> String
    {
        return self.codigo
    }
    
    func getEstilo() -> String
    {
        return self.estilo
    }
    
    // Não será utilizado na classe Produto, mas sim nas sobrescritas em suas subclasses
    func showInfo() -> String
    {
        return ""
    }
}