//
//  ShowInfo.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

protocol ShowInfo
{
    func showInfo() -> String
}
