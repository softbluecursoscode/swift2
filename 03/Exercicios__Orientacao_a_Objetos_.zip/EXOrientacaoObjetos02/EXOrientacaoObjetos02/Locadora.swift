//
//  Locadora.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class Locadora
{
    private var funcionarios : NSMutableArray!
    private var usuarios : NSMutableArray!
    private var produtos : NSMutableArray!
    private var locacoes : NSMutableArray!
    
    init()
    {
        self.funcionarios = NSMutableArray()
        self.usuarios = NSMutableArray()
        self.produtos = NSMutableArray()
        self.locacoes = NSMutableArray()
    }
    
    func adicionarFuncionario(funcionario: Funcionario) -> Void
    {
        self.funcionarios.addObject(funcionario)
    }
    
    func adicionarUsuario(usuario: Usuario) -> Void
    {
        self.usuarios.addObject(usuario)
    }
    
    func adicionarProduto(produto: Produto) -> Void
    {
        self.produtos.addObject(produto)
    }
    
    func adicionarLocacao(locacao: Locacao) -> Void
    {
        self.locacoes.addObject(locacao)
    }
    
    func listaFuncionarios() -> String
    {
        var buffer : String = "Lista de funcionários: \n\n"
        var i : Int
        
        // Para cada item da lista captura o seu showInfo
        for i=0; i<self.funcionarios.count; i++
        {
            var temp : Funcionario = self.funcionarios.objectAtIndex(i) as Funcionario
            
            buffer = "\(buffer) \(temp.showInfo()) \n\n"
        }
        
        return buffer
    }
    
    func listaUsuarios() -> String
    {
        var buffer : String = "Lista de usuários: \n\n"
        var i : Int
        
        // Para cada item da lista captura o seu showInfo
        for i=0; i<self.usuarios.count; i++
        {
            var temp : Usuario = self.usuarios.objectAtIndex(i) as Usuario
            
            buffer = "\(buffer) \(temp.showInfo()) \n\n"
        }
        
        return buffer
    }
    
    func listaProdutos() -> String
    {
        var buffer : String = "Lista de produtos: \n\n"
        var i : Int
        
        // Para cada item da lista captura o seu showInfo
        for i=0; i<self.produtos.count; i++
        {
            var temp : Produto = self.produtos.objectAtIndex(i) as Produto
            
            buffer = "\(buffer) \(temp.showInfo()) \n\n"
        }
        
        return buffer
    }
    
    func listaLocacoes() -> String
    {
        var buffer : String = "Lista de locacoes: \n\n"
        var i : Int
        
        // Para cada item da lista captura o seu showInfo
        for i=0; i<self.locacoes.count; i++
        {
            var temp : Locacao = self.locacoes.objectAtIndex(i) as Locacao
            
            buffer = "\(buffer) \(temp.showInfo()) \n\n"
        }
        
        return buffer
    }
    
    
    func getFuncionarioPeloNome(nome: String) -> Funcionario!
    {
        var i : Int
        
        for i=0; i<self.funcionarios.count; i++
        {
            var f : Funcionario = self.funcionarios.objectAtIndex(i) as Funcionario
            
            if(f.getNome() == nome)
            {
                return f
            }
        }
        
        return nil
    }
    
    func getUsuarioPeloNome(nome: String) -> Usuario!
    {
        var i : Int
        
        for i=0; i<self.usuarios.count; i++
        {
            var u : Usuario = self.usuarios.objectAtIndex(i) as Usuario
            
            if(u.getNome() == nome)
            {
                return u
            }
        }
        
        return nil
    }
    
    func getProdutoPeloCodigo(codigo: String) -> Produto!
    {
        var i : Int
        
        for i=0; i<self.produtos.count; i++
        {
            var p : Produto = self.produtos.objectAtIndex(i) as Produto
            
            if(p.getCodigo() == codigo)
            {
                return p
            }
        }
        
        return nil
    }
    
}








