//
//  CD.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class CD: Produto
{
    private var artista : String!
    private var album : String!
    
    init(estilo: String, codigo: String, artista: String, album: String)
    {
        super.init(estilo: estilo, codigo: codigo)
        
        self.artista = artista
        self.album = album
    }
    
    override func showInfo() -> String
    {
        var info = "Info CD: \(self.getEstilo()) \(self.getCodigo()) \(self.artista) \(self.album)"
        
        return info
    }
}
