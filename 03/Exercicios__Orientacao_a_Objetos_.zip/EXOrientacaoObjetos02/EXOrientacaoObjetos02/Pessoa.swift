//
//  Pessoa.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class Pessoa
{
    private var nome : String!
    private var telefone : String!
    private var endereco : String!
    
    init(nome: String, telefone: String, endereco: String)
    {
        self.nome = nome
        self.telefone = telefone
        self.endereco = endereco
    }
    
    func getNome() -> String
    {
        return self.nome
    }
    
    func getTelefone() -> String
    {
        return self.telefone
    }
    
    func getEndereco() -> String
    {
        return self.endereco
    }
}
