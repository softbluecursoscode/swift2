//
//  Funcionario.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class Funcionario: Pessoa, ShowInfo
{
    private var salario : Float!
    
    init(nome: String, telefone: String, endereco: String, salario: Float)
    {
        super.init(nome: nome, telefone: telefone, endereco: endereco)
        
        self.salario = salario
    }
    
    func showInfo() -> String
    {
        var info = "Info Funcionario: \(self.getNome()) \(self.getTelefone()) \(self.getEndereco()) \(self.salario)"
        
        return info
    }
}
