//
//  Usuario.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class Usuario: Pessoa, ShowInfo
{
    private var numeroDeLocacoes : Int!
    
    init(nome: String, telefone: String, endereco: String, numeroDeLocacoes: Int)
    {
        super.init(nome: nome, telefone: telefone, endereco: endereco)
        
        self.numeroDeLocacoes = numeroDeLocacoes
    }
    
    func setNumeroDeLocacoes(numeroDeLocacoes: Int) -> Void
    {
        self.numeroDeLocacoes = numeroDeLocacoes
    }
    
    func getNumeroDeLocacoes() -> Int
    {
        return self.numeroDeLocacoes
    }
    
    func showInfo() -> String
    {
        var info = "Info Pessoa: \(self.getNome()) \(self.getTelefone()) \(self.getEndereco()) \(self.numeroDeLocacoes)"
        
        return info
    }
}