//
//  ViewController.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        /**************************
        *** CRIANDO A LOCADORA ***
        ***************************/
        var locadora : Locadora = Locadora()
        
        
        
        /******************************
        *** INSERINDO FUNCIONÁRIOS ***
        ******************************/
        var funcionario : Funcionario
        
        funcionario = Funcionario(nome: "André", telefone: "9999-9999", endereco: "Rua da Softblue", salario: 1000)
        locadora.adicionarFuncionario(funcionario)
        
        funcionario = Funcionario(nome: "Carlos", telefone: "8888-8888", endereco: "Rua da Softblue", salario: 2000)
        locadora.adicionarFuncionario(funcionario)
        
        
        
        /**************************
        *** INSERINDO USUÁRIOS ***
        **************************/
        var usuario : Usuario
        
        usuario = Usuario(nome: "Fernando", telefone: "7777-7777", endereco: "Rua Brasil", numeroDeLocacoes: 0)
        locadora.adicionarUsuario(usuario)
        
        usuario = Usuario(nome: "Samuel", telefone: "6666-6666", endereco: "Rua México", numeroDeLocacoes: 0)
        locadora.adicionarUsuario(usuario)
        
        
        
        /**************************
        *** INSERINDO PRODUTOS ***
        **************************/
        var produto : Produto
        
        produto = CD(estilo: "Rock", codigo: "1", artista: "U2", album: "Zooropa")
        locadora.adicionarProduto(produto)
        
        produto = DVD(estilo: "Suspense", codigo: "2", titulo: "A Noite Chuvosa")
        locadora.adicionarProduto(produto)
        
        produto = Bluray(estilo: "Ação", codigo: "3", titulo: "O Tesouro", resolucao: "FullHD")
        locadora.adicionarProduto(produto)
        
        
        
        /**************************
        *** INSERINDO LOCAÇÕES ***
        **************************/
        var locacao : Locacao
        
        // Observe que é necessário capturar os objetos pelos seus
        // nomes ou códigos, neste exemplo, para utilizá-los na criação da locação
        
        funcionario = locadora.getFuncionarioPeloNome("André")!
        usuario = locadora.getUsuarioPeloNome("Samuel")!
        produto = locadora.getProdutoPeloCodigo("1")!
        locacao = Locacao(funcionario: funcionario, usuario: usuario, produto: produto)
        locadora.adicionarLocacao(locacao)
        
        funcionario = locadora.getFuncionarioPeloNome("Carlos")!
        usuario = locadora.getUsuarioPeloNome("Fernando")!
        produto = locadora.getProdutoPeloCodigo("2")!
        locacao = Locacao(funcionario: funcionario, usuario: usuario, produto: produto)
        locadora.adicionarLocacao(locacao)
        
        funcionario = locadora.getFuncionarioPeloNome("André")!
        usuario = locadora.getUsuarioPeloNome("Samuel")!
        produto = locadora.getProdutoPeloCodigo("3")!
        locacao = Locacao(funcionario: funcionario, usuario: usuario, produto: produto)
        locadora.adicionarLocacao(locacao)
        
        
        
        /*****************************************************************************************************
        *** EXIBINDO INFORMAÇÕES ****************************************************************************
        *** Serão abertas 4 UIAlertViews que serão empilhadas na tela do seu dispositivo. Por este motivo ***
        *** as telas estarão disponíveis de trás para frente, de acordo com a ordem apresentada a seguir. ***
        *****************************************************************************************************/
        
        // Funcionários
        var myAlertF : UIAlertView = UIAlertView()
        myAlertF.title = "Funcionários"
        myAlertF.message = locadora.listaFuncionarios()
        myAlertF.addButtonWithTitle("OK")
        myAlertF.show()
        
        // Usuários
        var myAlertU : UIAlertView = UIAlertView()
        myAlertU.title = "Usuários"
        myAlertU.message = locadora.listaUsuarios()
        myAlertU.addButtonWithTitle("OK")
        myAlertU.show()
        
        // Produtos
        var myAlertP : UIAlertView = UIAlertView()
        myAlertP.title = "Produtos"
        myAlertP.message = locadora.listaProdutos()
        myAlertP.addButtonWithTitle("OK")
        myAlertP.show()
        
        // Locações
        var myAlertL : UIAlertView = UIAlertView()
        myAlertL.title = "Locações"
        myAlertL.message = locadora.listaLocacoes()
        myAlertL.addButtonWithTitle("OK")
        myAlertL.show()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

