//
//  Bluray.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class Bluray: Produto
{
    private var titulo : String!
    private var resolucao : String!
    
    init(estilo: String, codigo: String, titulo: String, resolucao: String)
    {
        super.init(estilo: estilo, codigo: codigo)
        
        self.titulo = titulo
        self.resolucao = resolucao
    }
    
    override func showInfo() -> String
    {
        var info = "Info Bluray: \(self.getEstilo()) \(self.getCodigo()) \(self.titulo) \(self.resolucao)"
        
        return info
    }
}
