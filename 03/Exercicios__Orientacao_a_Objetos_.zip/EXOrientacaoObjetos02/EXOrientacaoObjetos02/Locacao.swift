//
//  Locacao.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class Locacao: ShowInfo
{
    private var funcionario : Funcionario
    private var usuario : Usuario
    private var produto : Produto
    
    init(funcionario: Funcionario, usuario: Usuario, produto: Produto)
    {
        self.funcionario = funcionario
        self.usuario = usuario
        self.produto = produto
        
        // Atualiza o número de locações do usuário
        var locacoes : Int = usuario.getNumeroDeLocacoes()
        locacoes++
        usuario.setNumeroDeLocacoes(locacoes)
    }
    
    func showInfo() -> String
    {
        var info = "Info Locacao: \(self.funcionario.showInfo()) \(self.usuario.showInfo()) \(self.produto.showInfo())"
        
        return info
    }
}
