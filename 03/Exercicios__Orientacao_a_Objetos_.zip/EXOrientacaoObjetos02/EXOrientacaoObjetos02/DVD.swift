//
//  DVD.swift
//  EXOrientacaoObjetos02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class DVD: Produto
{
    private var titulo : String!
    
    init(estilo: String, codigo: String, titulo: String)
    {
        super.init(estilo: estilo, codigo: codigo)
        
        self.titulo = titulo
    }
    
    override func showInfo() -> String
    {
        var info = "Info CD: \(self.getEstilo()) \(self.getCodigo()) \(self.titulo)"
        
        return info
    }
}
