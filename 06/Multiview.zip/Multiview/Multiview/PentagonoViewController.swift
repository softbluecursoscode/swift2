//
//  PentagonoViewController.swift
//  Multiview
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class PentagonoViewController: UIViewController {

    @IBOutlet weak var myTextfield : UITextField?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func textFieldReturn(sender: AnyObject)
    {
        sender.resignFirstResponder()
    }
    
    @IBAction func backgroundTouch()
    {
        myTextfield?.resignFirstResponder()
    }
    
    @IBAction func sendValue()
    {
        var myAppDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        myAppDelegate.sharedValue = myTextfield?.text
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
