//
//  ViewController.swift
//  EXInternacionalizacao01
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    // IMPORTANTE: Após criar as diferentes versões dos arquivos envolvidos neste projeto
    // utilize a opção Product -> Clean caso esteja com dificuldades para ver na tela
    // os valores atualizados
    
    @IBOutlet weak var myPickerView : UIPickerView!
    @IBOutlet weak var myLabel : UILabel!
    @IBOutlet weak var myButton : UIButton!
    
    var myPickerDataSource : NSArray!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        // Carrega os dados do picker
        var filepath : String = NSBundle.mainBundle().pathForResource("myProperties", ofType: "plist")!
        myPickerDataSource = NSMutableArray(contentsOfFile: filepath)
        
        // Carrega os textos traduzidos para os componentes do formulário
        myLabel.text = NSLocalizedString("LabelText", comment: "")
        myButton.setTitle(NSLocalizedString("ButtonTitle", comment: ""), forState: UIControlState.Normal)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return myPickerDataSource.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String!
    {
        return myPickerDataSource.objectAtIndex(row) as String
    }

    @IBAction func showInfo()
    {
        // Captura o valor do picker
        
        var myRow : Int = myPickerView.selectedRowInComponent(0)
        var myValue : String = myPickerDataSource.objectAtIndex(myRow) as String
        
        // Cria a mensagem
        
        var myAlert = UIAlertView()
        myAlert.title = NSLocalizedString("UIAlertViewTitle", comment: "")
        myAlert.message = "\(myValue)"
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
}


