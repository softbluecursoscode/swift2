//
//  ViewController.swift
//  Localization
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myLabel : UILabel!
    @IBOutlet weak var myTextfield : UITextField!
    @IBOutlet weak var myButton : UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        myLabel.text = NSLocalizedString("Texto da label", comment: "")
        
        myTextfield.placeholder = NSLocalizedString("Texto do textfield", comment: "")
        
        myButton.setTitle(NSLocalizedString("Texto do botao", comment: ""), forState: UIControlState.Normal)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func doSomething()
    {
        var myAlert = UIAlertView()
        myAlert.title = NSLocalizedString("Titulo do alerta", comment: "")
        myAlert.message = NSLocalizedString("Mensagem do alerta", comment: "")
        myAlert.addButtonWithTitle(NSLocalizedString("Botao do alerta", comment: ""))
        myAlert.show()
    }

}

