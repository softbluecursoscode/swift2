//
//  ViewController.swift
//  EXMovimentos02
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    
    var motionManager : CMMotionManager!
    
    @IBOutlet weak var labelGyroscopeX : UILabel!
    @IBOutlet weak var labelGyroscopeY : UILabel!
    @IBOutlet weak var labelGyroscopeZ : UILabel!
    
    @IBOutlet weak var labelGyroscopeXMax : UILabel!
    @IBOutlet weak var labelGyroscopeYMax : UILabel!
    @IBOutlet weak var labelGyroscopeZMax : UILabel!
    
    // Variáveis que irão gerenciar os valores máximos lidos
    var maxX : Double!
    var maxY : Double!
    var maxZ : Double!
    
    @IBAction func resetLabels()
    {
        labelGyroscopeXMax.text = "0"
        labelGyroscopeYMax.text = "0"
        labelGyroscopeZMax.text = "0"
        
        maxX = 0
        maxY = 0
        maxZ = 0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Reseta as labels assim que a aplicação inicia
        resetLabels()
        
        // Inicia o giroscópio
        motionManager = CMMotionManager()
        
        if(motionManager.gyroAvailable)
        {
            motionManager.gyroUpdateInterval = 1.0 / 10.0
            
            motionManager.startGyroUpdatesToQueue(NSOperationQueue())
                {
                    (data, error) in dispatch_async(dispatch_get_main_queue())
                        {
                            if(error != nil)
                            {
                                var myAlert : UIAlertView = UIAlertView()
                                myAlert.title = "Erro"
                                myAlert.message = "Falha no giroscópio"
                                myAlert.addButtonWithTitle("OK")
                                myAlert.show()
                            }
                            else
                            {
                                self.labelGyroscopeX.text = NSString(format: "%.2f", data.rotationRate.x)
                                self.labelGyroscopeY.text = NSString(format: "%.2f", data.rotationRate.y)
                                self.labelGyroscopeZ.text = NSString(format: "%.2f", data.rotationRate.z)
                                
                                if(data.rotationRate.x > self.maxX)
                                {
                                    self.maxX = data.rotationRate.x
                                    self.labelGyroscopeXMax.text = self.labelGyroscopeX.text
                                }
                                
                                if(data.rotationRate.y > self.maxY)
                                {
                                    self.maxY = data.rotationRate.y
                                    self.labelGyroscopeYMax.text = self.labelGyroscopeY.text
                                }
                                
                                if(data.rotationRate.z > self.maxZ)
                                {
                                    self.maxZ = data.rotationRate.z
                                    self.labelGyroscopeZMax.text = self.labelGyroscopeZ.text
                                }
                            }
                    }
            }
        }
        else
        {
            var myAlert : UIAlertView = UIAlertView()
            myAlert.title = "Erro"
            myAlert.message = "Sem giroscópio"
            myAlert.addButtonWithTitle("OK")
            myAlert.show()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

