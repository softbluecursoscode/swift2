//
//  ViewController.swift
//  EXMovimentos01
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    
    var motionManager : CMMotionManager!
    
    @IBOutlet weak var labelAccelerometerX : UILabel!
    @IBOutlet weak var labelAccelerometerY : UILabel!
    @IBOutlet weak var labelAccelerometerZ : UILabel!
    @IBOutlet weak var labelAviso : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        motionManager = CMMotionManager()
        
        if(motionManager.accelerometerAvailable)
        {
            motionManager.accelerometerUpdateInterval = 1.0 / 10.0
            
            motionManager.startAccelerometerUpdatesToQueue(NSOperationQueue())
                {
                    (data, error) in dispatch_async(dispatch_get_main_queue())
                        {
                            if(error != nil)
                            {
                                var myAlert : UIAlertView = UIAlertView()
                                myAlert.title = "Erro"
                                myAlert.message = "Falha no acelerômetro"
                                myAlert.addButtonWithTitle("OK")
                                myAlert.show()
                            }
                            else
                            {
                                self.labelAccelerometerX.text = NSString(format: "%.2f", data.acceleration.x)
                                self.labelAccelerometerY.text = NSString(format: "%.2f", data.acceleration.y)
                                self.labelAccelerometerZ.text = NSString(format: "%.2f", data.acceleration.z)
                                
                                if(data.acceleration.y > 0.95 || data.acceleration.y < -0.95)
                                {
                                    self.labelAviso.text = "Limite de 95%"
                                }
                                else
                                {
                                    self.labelAviso.text = ""
                                }
                            }
                    }
            }
        }
        else
        {
            var myAlert : UIAlertView = UIAlertView()
            myAlert.title = "Erro"
            myAlert.message = "Sem acelerômetro"
            myAlert.addButtonWithTitle("OK")
            myAlert.show()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

