//
//  ViewController.swift
//  Movimentos
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    
    var motionManager : CMMotionManager!
    
    @IBOutlet weak var labelAccelerometerX : UILabel!
    @IBOutlet weak var labelAccelerometerY : UILabel!
    @IBOutlet weak var labelAccelerometerZ : UILabel!
    
    @IBOutlet weak var labelGyroscopeX : UILabel!
    @IBOutlet weak var labelGyroscopeY : UILabel!
    @IBOutlet weak var labelGyroscopeZ : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        motionManager = CMMotionManager()
        
        if(motionManager.accelerometerAvailable)
        {
            motionManager.accelerometerUpdateInterval = 1.0 / 10.0
            
            motionManager.startAccelerometerUpdatesToQueue(NSOperationQueue())
            {
                (data, error) in dispatch_async(dispatch_get_main_queue())
                {
                    // === Início da lógica do acelerômetro
                    
                    if(error != nil)
                    {
                        var myAlert : UIAlertView = UIAlertView()
                        myAlert.title = "Erro"
                        myAlert.message = "Falha no acelerômetro"
                        myAlert.addButtonWithTitle("OK")
                        myAlert.show()
                    }
                    else
                    {
                        self.labelAccelerometerX.text = NSString(format: "%.2f", data.acceleration.x)
                        self.labelAccelerometerY.text = NSString(format: "%.2f", data.acceleration.y)
                        self.labelAccelerometerZ.text = NSString(format: "%.2f", data.acceleration.z)
                    }
                    
                    // === Fim
                }
            }
        }
        else
        {
            var myAlert : UIAlertView = UIAlertView()
            myAlert.title = "Erro"
            myAlert.message = "Sem acelerômetro"
            myAlert.addButtonWithTitle("OK")
            myAlert.show()
        }
        
        if(motionManager.gyroAvailable)
        {
            motionManager.gyroUpdateInterval = 1.0 / 10.0
            
            motionManager.startGyroUpdatesToQueue(NSOperationQueue())
                {
                    (data, error) in dispatch_async(dispatch_get_main_queue())
                        {
                            // === Início da lógica do giroscópio
                            
                            if(error != nil)
                            {
                                var myAlert : UIAlertView = UIAlertView()
                                myAlert.title = "Erro"
                                myAlert.message = "Falha no giroscópio"
                                myAlert.addButtonWithTitle("OK")
                                myAlert.show()
                            }
                            else
                            {
                                self.labelGyroscopeX.text = NSString(format: "%.2f", data.rotationRate.x)
                                self.labelGyroscopeY.text = NSString(format: "%.2f", data.rotationRate.y)
                                self.labelGyroscopeZ.text = NSString(format: "%.2f", data.rotationRate.z)
                            }
                            
                            // === Fim
                    }
            }
        }
        else
        {
            var myAlert : UIAlertView = UIAlertView()
            myAlert.title = "Erro"
            myAlert.message = "Sem giroscópio"
            myAlert.addButtonWithTitle("OK")
            myAlert.show()
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

