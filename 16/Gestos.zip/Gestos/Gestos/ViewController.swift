//
//  ViewController.swift
//  Gestos
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var labelStatus : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var longPressGestureRecognizer : UILongPressGestureRecognizer = UILongPressGestureRecognizer(target: self, action: NSSelectorFromString("longPressEvent:"))
        longPressGestureRecognizer.numberOfTapsRequired = 1
        longPressGestureRecognizer.minimumPressDuration = 2
        self.view.addGestureRecognizer(longPressGestureRecognizer)
        
        var tapGestureRecognizer : UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: NSSelectorFromString("tapEvent:"))
        tapGestureRecognizer.numberOfTapsRequired = 2
        self.view.addGestureRecognizer(tapGestureRecognizer)
        
        var swipeGestureRecognizerLeft : UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: NSSelectorFromString("swipeLeftEvent:"))
        swipeGestureRecognizerLeft.direction = UISwipeGestureRecognizerDirection.Left
        self.view.addGestureRecognizer(swipeGestureRecognizerLeft)
        
        var swipeGestureRecognizerRight : UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: NSSelectorFromString("swipeRightEvent:"))
        swipeGestureRecognizerRight.direction = UISwipeGestureRecognizerDirection.Right
        self.view.addGestureRecognizer(swipeGestureRecognizerRight)
        
        var rotationGestureRecognizer : UIRotationGestureRecognizer = UIRotationGestureRecognizer(target: self, action: NSSelectorFromString("rotationEvent:"))
        self.view.addGestureRecognizer(rotationGestureRecognizer)
        
        var pinchGestureRecognizer : UIPinchGestureRecognizer = UIPinchGestureRecognizer(target: self, action: NSSelectorFromString("pinchEvent:"))
        self.view.addGestureRecognizer(pinchGestureRecognizer)
    }
    
    @IBAction func longPressEvent(sender: UIGestureRecognizer)
    {
        var location : CGPoint = sender.locationInView(self.view)
        
        labelStatus.text = "Toque longo: \(location.x), \(location.y)"
    }
    
    @IBAction func tapEvent(sender: UIGestureRecognizer)
    {
        var location : CGPoint = sender.locationInView(self.view)
        
        labelStatus.text = "Toque duplo rápido: \(location.x), \(location.y)"
    }
    
    @IBAction func swipeLeftEvent(sender: UIGestureRecognizer)
    {
        labelStatus.text = "Toque realizado para a esquerda"
    }
    
    @IBAction func swipeRightEvent(sender: UIGestureRecognizer)
    {
        labelStatus.text = "Toque realizado para a direita"
    }
    
    @IBAction func rotationEvent(sender: UIRotationGestureRecognizer)
    {
        var rotation : CGFloat = sender.rotation
        var velocity : CGFloat = sender.velocity
        
        labelStatus.text = "Rotação: \(rotation) \u{00B0}, \(velocity)"
    }
    
    @IBAction func pinchEvent(sender: UIPinchGestureRecognizer)
    {
        var scale : CGFloat = sender.scale
        var velocity : CGFloat = sender.velocity
        
        labelStatus.text = "Pinça: \(scale), \(velocity)"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

