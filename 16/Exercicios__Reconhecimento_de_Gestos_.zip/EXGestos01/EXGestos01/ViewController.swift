//
//  ViewController.swift
//  GuiaGestos
//
//  Created by Andre Milani on 20/12/14.
//  Copyright (c) 2014 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var labelStatus : UILabel!
    
    var up : Bool!
    var down : Bool!
    var left : Bool!
    var right : Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var swipeGestureRecognizerUp : UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: NSSelectorFromString("swipeUpEvent:"))
        swipeGestureRecognizerUp.direction = UISwipeGestureRecognizerDirection.Up
        self.view.addGestureRecognizer(swipeGestureRecognizerUp)
        
        var swipeGestureRecognizerDown : UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: NSSelectorFromString("swipeDownEvent:"))
        swipeGestureRecognizerDown.direction = UISwipeGestureRecognizerDirection.Down
        self.view.addGestureRecognizer(swipeGestureRecognizerDown)
        
        var swipeGestureRecognizerLeft : UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: NSSelectorFromString("swipeLeftEvent:"))
        swipeGestureRecognizerLeft.direction = UISwipeGestureRecognizerDirection.Left
        self.view.addGestureRecognizer(swipeGestureRecognizerLeft)
        
        var swipeGestureRecognizerRight : UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: NSSelectorFromString("swipeRightEvent:"))
        swipeGestureRecognizerRight.direction = UISwipeGestureRecognizerDirection.Right
        self.view.addGestureRecognizer(swipeGestureRecognizerRight)
        
        resetSequence()
    }
    
    // Função que reseta os indicadores de cada gesto da sequência
    func resetSequence()
    {
        up = false
        down = false
        left = false
        right = false
    }
    
    @IBAction func swipeUpEvent(sender: UIGestureRecognizer)
    {
        // Sempre que um toque para cima for realizado, o sistema reseta a sequência, esperando que uma nova
        // esteja sendo iniciada
        resetSequence()
        
        // E já marca que o movimento para cima foi realizado
        up = true
    }
    
    @IBAction func swipeDownEvent(sender: UIGestureRecognizer)
    {
        // Somente aceita o movimento para baixo caso o movimento para cima tenha sido feito
        if(up == true)
        {
            down = true
        }
        
        // Caso contrário invalida toda a sequência
        else
        {
            resetSequence()
        }
    }
    
    @IBAction func swipeLeftEvent(sender: UIGestureRecognizer)
    {
        // Somente aceita o movimento para a esquerda caso os movimentos para cima e para baixo tenham sido feitos
        if(up == true && down == true)
        {
            left = true
        }
            
            // Caso contrário invalida toda a sequência
        else
        {
            resetSequence()
        }
    }
    
    @IBAction func swipeRightEvent(sender: UIGestureRecognizer)
    {
        // Somente aceita o movimento para a direita caso os movimentos para cima, para baixo 
        // e para a esquerda tenham sido feitos
        if(up == true && down == true && left == true)
        {
            right = true
            
            var myAlert : UIAlertView = UIAlertView()
            myAlert.title = "SUCESSO"
            myAlert.message = "Sequência realizada com sucesso!"
            myAlert.addButtonWithTitle("OK")
            myAlert.show()
            
            resetSequence()
        }
            
        // Caso contrário invalida toda a sequência
        else
        {
            resetSequence()
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}



