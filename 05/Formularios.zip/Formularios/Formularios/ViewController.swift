//
//  ViewController.swift
//  Formularios
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIActionSheetDelegate {
    
    @IBOutlet weak var textFieldSomeText : UITextField?
    @IBOutlet weak var labelSliderValue : UILabel?
    @IBOutlet weak var mySlider : UISlider?
    @IBOutlet weak var mySwitch : UISwitch?
    
    @IBAction func showAlert()
    {
        let myAlert = UIAlertView()
        myAlert.title = "Alerta"
        myAlert.message = "Mensagem de alerta"
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
    @IBAction func showText()
    {
        let myAlert = UIAlertView()
        myAlert.title = "Valor do campo"
        myAlert.message = textFieldSomeText?.text
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
    @IBAction func showSwitch()
    {
        var myMessage : String
        
        if(mySwitch?.on == true)
        {
            myMessage = "Switch ligado"
        }
        else
        {
            myMessage = "Switch desligado"
        }
        
        let myAlert = UIAlertView()
        myAlert.title = "Valor do Switch"
        myAlert.message = myMessage
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
    @IBAction func opcaoA()
    {
        let myAlert = UIAlertView()
        myAlert.title = "Alerta"
        myAlert.message = "Realizando a ação A"
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
    @IBAction func opcaoB()
    {
        let myAlert = UIAlertView()
        myAlert.title = "Alerta"
        myAlert.message = "Realizando a ação B"
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
    @IBAction func askConfirmation()
    {
        var myActionSheet = UIAlertController(title: "Qual ação você deseja realizar?", message: nil, preferredStyle: UIAlertControllerStyle.ActionSheet)
        
        var myActionA = UIAlertAction(title: "Opção A", style: UIAlertActionStyle.Default,
            handler: { (ACTION:UIAlertAction!)in self.opcaoA() } )
        
        var myActionB = UIAlertAction(title: "Opção B", style: UIAlertActionStyle.Default,
            handler: { (ACTION:UIAlertAction!)in self.opcaoB() } )
        
        var myActionC = UIAlertAction(title: "Cancelar", style: UIAlertActionStyle.Cancel,
            handler: nil )
        
        myActionSheet.addAction(myActionA)
        myActionSheet.addAction(myActionB)
        myActionSheet.addAction(myActionC)
        
        self.presentViewController(myActionSheet, animated: true, completion: nil)
    }
    
    @IBAction func sliderValueChanged()
    {
        var sliderFloatValue : Float!
        sliderFloatValue = mySlider?.value
        
        var sliderIntValue : Int
        sliderIntValue = Int(sliderFloatValue)
        
        var newLabelText : String
        newLabelText = "\(sliderIntValue)%"
        
        labelSliderValue?.text = newLabelText
    }
    
    @IBAction func textFieldReturn(sender: AnyObject)
    {
        sender.resignFirstResponder()
    }
    
    @IBAction func backgroundTouch()
    {
        textFieldSomeText?.resignFirstResponder()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

