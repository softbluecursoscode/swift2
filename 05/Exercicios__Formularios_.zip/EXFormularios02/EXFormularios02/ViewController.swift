//
//  ViewController.swift
//  EXFormularios02
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLabel : UILabel!
    @IBOutlet weak var mySlider : UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func atualizar()
    {
        var sliderFloatValue : Float!
        sliderFloatValue = mySlider.value
        
        var sliderIntValue : Int
        sliderIntValue = Int(sliderFloatValue)
        
        var newLabelText : String
        newLabelText = "\(sliderIntValue)"
        
        myLabel.text = newLabelText
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

