//
//  ViewController.swift
//  EXFormularios03
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLabel : UILabel!
    @IBOutlet weak var mySwitch : UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func processarInterruptor()
    {
        if(mySwitch.on)
        {
            myLabel.text = "Ligado"
        }
        else
        {
            myLabel.text = "Desligado"
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

