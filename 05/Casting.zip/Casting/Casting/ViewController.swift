//
//  ViewController.swift
//  Casting
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var texto : String
        var inteiro : Int
        var decimal : Float
        var decimalDouble : Double
        
        // Int para String
        inteiro = 10
        texto = "\(inteiro)"
        texto = String(inteiro)
        print(texto + "\n")
        
        // Float para String
        decimal = 5.55
        
        texto = "\(decimal)"
        print(texto + "\n")
        
        texto = String(format: "%f", decimal)
        print(texto + "\n")
        
        // String para Int
        texto = "7"
        
        inteiro = texto.toInt()!
        inteiro++
        print(inteiro)
        print("\n")
        
        // String para Float
        texto = "1.234"
        
        var textoNS : NSString = texto
        decimal = textoNS.floatValue
        decimal++
        print(decimal)
        print("\n")
        
        // String para Double
        decimalDouble = textoNS.doubleValue
        decimalDouble++
        print(decimalDouble)
        print("\n")
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

