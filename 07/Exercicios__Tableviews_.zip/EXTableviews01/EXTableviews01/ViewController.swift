//
//  ViewController.swift
//  EXTableviews01
//
//  Created by Andre Milani on 05/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var listValues : NSDictionary = NSDictionary()
    var listKeys : NSMutableArray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var filepath : String = NSBundle.mainBundle().pathForResource("myCollection", ofType: "plist")!
        
        listValues = NSDictionary(contentsOfFile: filepath)!
        
        listKeys = NSMutableArray(array: listValues.allKeys)
        
        listKeys.sortUsingSelector(NSSelectorFromString("compare:"))
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Métodos que devem ser implementados do protocolo UITableViewDataSource
    
    // Retorna o número de seções que a tabela gerencia
    func numberOfSectionsInTableView(tableView: UITableView?) -> Int
    {
        return listKeys.count
    }

    // Retorna o número de linhas para cada seção de dados da tabela
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var myKey : String = listKeys.objectAtIndex(section) as String
        var sectionList : NSArray = listValues.objectForKey(myKey) as NSArray
        return sectionList.count
    }
    
    // Retorna a célula preenchida com os dados quando o iOS solicita para exibí-la
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var myId : String = "identificador";
        
        var cell : UITableViewCell? = tableView.dequeueReusableCellWithIdentifier(myId) as? UITableViewCell
        
        if(cell == nil)
        {
            cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: myId)
        }
        
        var section : Int = indexPath.section
        var row : Int = indexPath.row
        
        var key : String = listKeys.objectAtIndex(section) as String
        var title : NSArray = listValues.objectForKey(key) as NSArray
        
        cell?.textLabel?.text = title.objectAtIndex(row) as? String
        
        return cell!
    }
    
    // Métodos que devem ser implementados do protocolo UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        // Pra exibir o texto clicado na tela basta capturá-lo da mesma forma como 
        // foi realizado para obter o texto e renderizar em cada célula: capturando
        // primeiro a seção clicada, depois a linha dentro da seção, e acessando
        // tudo isso no dicionário de dados
        
        var section : Int = indexPath.section
        var row : Int = indexPath.row
        
        var key : String = listKeys.objectAtIndex(section) as String
        var title : NSArray = listValues.objectForKey(key) as NSArray
        
        var buffer : String = title.objectAtIndex(row) as String
        
        let myAlert = UIAlertView()
        myAlert.title = "Tableview"
        myAlert.message = buffer
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
}



