//
//  ViewController.swift
//  TableviewIndexed
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var musicalGroups : NSDictionary = NSDictionary()
    var keysOfMusicalGroups : NSMutableArray = NSMutableArray()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var filepath : String = NSBundle.mainBundle().pathForResource("bandas", ofType: "plist")!
        
        // *** Foi alterado para NSMutableDictionary para contemplar o ordenamento de seus itens
        musicalGroups = NSMutableDictionary(contentsOfFile: filepath)!
        
        keysOfMusicalGroups = NSMutableArray(array: musicalGroups.allKeys)
        keysOfMusicalGroups.sortUsingSelector(NSSelectorFromString("compare:"))
        
        // *******************************************************************
        // *** Código para ordenamento dos itens dentro de cada seção (índice)
        // *******************************************************************
        
        // Para cada índice (letra) existente no dicionário de dados...
        for i in 0 ... keysOfMusicalGroups.count - 1
        {
            // Capture seu array de bandas...
            var key : String = keysOfMusicalGroups.objectAtIndex(i) as String
            var titles : NSArray = musicalGroups.objectForKey(key) as NSArray
            
            // Ordene o array capturado (precisa converter para NSMutableArray)...
            var mutableTitles : NSMutableArray = NSMutableArray(array: titles)
            mutableTitles.sortUsingSelector(NSSelectorFromString("compare:"))
            
            // Atualize o dicionário de dados com o array ordenado para essa letra...
            musicalGroups.setValue(mutableTitles, forKey: key)
        }
        
        // *******************************************************************
        // *** Fim do código
        // *******************************************************************
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var myKey : String = keysOfMusicalGroups.objectAtIndex(section) as String
        var sectionList : NSArray = musicalGroups.objectForKey(myKey) as NSArray
        return sectionList.count
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return keysOfMusicalGroups.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var myId : String = "texto"
        
        var cell : UITableViewCell? = tableView.dequeueReusableCellWithIdentifier(myId) as? UITableViewCell
        
        if(cell == nil)
        {
            cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: myId)
        }
        
        var section : Int = indexPath.section
        var row : Int = indexPath.row
        
        var key : String = keysOfMusicalGroups.objectAtIndex(section) as String
        var titles : NSArray = musicalGroups.objectForKey(key) as NSArray
        var musicalGroup : String = titles.objectAtIndex(row) as String
        
        cell?.textLabel?.text = musicalGroup
        
        return cell!
    }


    

}

