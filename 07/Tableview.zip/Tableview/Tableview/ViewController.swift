//
//  ViewController.swift
//  Tableview
//
//  Created by Andre Milani.
//  Copyright (c) Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var myDataSource : NSMutableArray = NSMutableArray()

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var myArray : NSMutableArray?
        
        for i in 0...20
        {
            var tempNome : String = "Nome \(i)"
            var tempSobrenome : String = "Sobrenome \(i)"
            var tempUsuario : NSArray = NSArray(objects: tempNome, tempSobrenome)
            self.myDataSource.addObject(tempUsuario)
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.myDataSource.count
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        var myObject : NSArray = self.myDataSource.objectAtIndex(indexPath.row) as NSArray
        var myMessage : String = String(myObject.objectAtIndex(0) as String) + String(myObject.objectAtIndex(1) as String)
        
        let myAlert = UIAlertView()
        myAlert.title = "Tableview"
        myAlert.message = myMessage
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var myId : String = "exemplo"
        
        var cell : UITableViewCell? = tableView.dequeueReusableCellWithIdentifier(myId) as? UITableViewCell
        
        if(cell == nil)
        {
            cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: myId)
            
            //cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: myId)
            // value1, value2
        }
        
        var myObject : NSArray = self.myDataSource.objectAtIndex(indexPath.row) as NSArray
        
        cell?.textLabel?.text = myObject.objectAtIndex(0) as? String
        cell?.detailTextLabel?.text = myObject.objectAtIndex(1) as? String
        
        var myIcon : UIImage = UIImage(named: "img_tableIconCube.png")
        var myIconHighlighted : UIImage = UIImage(named: "img_tableIconCubeHighlighted.png")
        
        cell?.imageView?.image = myIcon
        cell?.imageView?.highlightedImage = myIconHighlighted

        return cell!
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

