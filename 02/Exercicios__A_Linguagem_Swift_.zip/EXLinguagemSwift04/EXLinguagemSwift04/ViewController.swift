//
//  ViewController.swift
//  EXLinguagemSwift04
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    func fatorial(valor: Int) -> Int
    {
        if(valor == 1)
        {
            return 1;
        }
        else
        {
            return valor * fatorial(valor-1);
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var buffer : String = ""
        var i : Int = fatorial(4)
        
        buffer = "\(i)"
        
        var myAlert : UIAlertView = UIAlertView()
        myAlert.title = "Resultado"
        myAlert.message = buffer
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

