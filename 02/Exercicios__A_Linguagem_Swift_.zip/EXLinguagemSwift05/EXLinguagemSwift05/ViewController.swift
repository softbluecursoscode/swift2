//
//  ViewController.swift
//  EXLinguagemSwift05
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    func calculaMedia(nota1: Float, nota2: Float, nota3: Float, peso1: Float, peso2: Float, peso3: Float) -> Float
    {
        return ((nota1 / 10) * peso1) + ((nota2 / 10) * peso2) + ((nota3 / 10) * peso3)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var buffer : String = ""
        var i : Float = calculaMedia(10, nota2: 9, nota3: 8, peso1: 3, peso2: 2, peso3: 5)
        
        buffer = "\(i)"
        
        var myAlert : UIAlertView = UIAlertView()
        myAlert.title = "Resultado"
        myAlert.message = buffer
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

