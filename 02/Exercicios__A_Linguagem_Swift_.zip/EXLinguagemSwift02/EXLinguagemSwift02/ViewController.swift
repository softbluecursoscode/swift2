//
//  ViewController.swift
//  EXLinguagemSwift02
//
//  Created by Andre Milani on 04/01/15.
//  Copyright (c) 2015 Softblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var buffer : String = ""
        var i : Int
        
        for i=1; i<=100; i++
        {
            if(i % 3 == 0)
            {
                buffer = "\(buffer) \(i)"
            }
        }
        
        var myAlert : UIAlertView = UIAlertView()
        myAlert.title = "Resultado"
        myAlert.message = buffer
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

