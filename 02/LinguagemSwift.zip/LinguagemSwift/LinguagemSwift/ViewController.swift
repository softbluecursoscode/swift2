//
//  ViewController.swift
//  LinguagemSwift
//

let myPINumber :  Float = 3.14

func retornaDobro(valor: Int) -> Int
{
    return valor * 2
}

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // STRING
        //var myBuffer = String()
        //var myBuffer : String = String()
        //myBuffer = "Hello World!"
        var myBuffer : String = "Texto"
        
        // OPERACOES MATEMATICAS
        var x : Int = 12
        var y : Int = 3
        var z : Float = Float(x) / Float(y)
        myBuffer = "Resultado: \(z)"
        
        // CONSTANTES
        z = myPINumber * 2
        myBuffer = "Resultado: \(z)"
        
        // FOR
        myBuffer = "For: "
        var i : Int
        
        //for i=0; i<=10; i++
        for i in 0...10
        {
            if(i == 3)
            {
                continue
            }
            
            myBuffer = "\(myBuffer) \(i)"
        }
        
        // WHILE
        myBuffer = "While: "
        i = 0
        
        while(i <= -5)
        {
            myBuffer = "\(myBuffer) \(i)"
            i++
        }
        
        // DO WHILE
        myBuffer = "Do while: "
        i = 0
        
        do
        {
            myBuffer = "\(myBuffer) \(i)"
            i++
        } while(i <= -5)
        
        // IF
        myBuffer = "If: "
        i = 4
        
        if(i > 5)
        {
            myBuffer = "i é maior que 5"
        }
        else if(i == 4)
        {
            myBuffer = "i vale 4"
        }
        else
        {
            myBuffer = "i é menor ou igual a 5 e não é 4"
        }
        
        // SHORT IF
        i = 6
        myBuffer = i > 5 ? "i maior que 5" : "i menor ou igual a 5"
        
        i = 7
        myBuffer = (i % 2 == 0) ? "PAR" : "ÍMPAR"
        
        // SWITCH
        i = 2
        switch(i)
        {
            case 1:
                myBuffer = "i entrou no case 1"
                break
            
            case 2:
                myBuffer = "i entrou no case 2"
                break
            
            case 3:
                myBuffer = "i entrou no case 3"
                break
            
            default:
                myBuffer = "i não entrou em nenhum case"
                break
        }
        
        // FUNCOES
        i = 6
        var w : Int = retornaDobro(i)
        myBuffer = "Dobro de \(i) é \(w)"
        
        // NSINTEGER
        var ins : NSInteger = 50
        
        // NSNUMBER
        var nns : NSNumber = 10.75
        
        // ARRAY
        var myArray : [String] = ["Vermelho", "Verde", "Azul"]
        var pos : Int = 1
        
        var myElement : String = myArray[pos]
        myBuffer = "Na posição \(pos) está o objeto \(myElement)"
        
        var total : Int = myArray.count
        myBuffer = "Meu array contém \(total) elementos"
        
        myBuffer = "Cores: "
        for color in myArray
        {
            myBuffer = "\(myBuffer) \(color)"
        }
        
        // NSARRAY (fixo)
        var myArrayNS : NSArray = ["Vermelho", 75, "Azul"]

        myBuffer = "Elementos: "
        for element in myArrayNS
        {
            myBuffer = "\(myBuffer) \(element)"
        }

        // NSMUTABLEARRAY (editável)
        var myMutableArrayNS : NSMutableArray = ["Vermelho", 75, "Azul"]
        
        //myMutableArrayNS.setObject(80, atIndexedSubscript: 1)
        myMutableArrayNS[1] = 80
        
        myMutableArrayNS.insertObject("Amarelo", atIndex: 2)
        
        myBuffer = "Elementos (NS): "
        for element in myMutableArrayNS
        {
            myBuffer = "\(myBuffer) \(element)"
        }
        
        // NSDICTIONARY
        var myDictionary : NSDictionary = ["V" : "Vermelho", "U" : 1, "AAA1111" : "Corvette"]
        var myKey : String = "U"
        var myObject : AnyObject
        
        myObject = myDictionary.objectForKey(myKey)!
        
        myBuffer = "A chave \(myKey) é do objeto \(myObject)"
        
        // NS ASSERT
        i = 50
        
        i = -13
        
        var myCondition : Bool = i > 0
        assert(myCondition, "Problemas na idade")
        
        
        // ALERTA
        let myAlert = UIAlertView()
        myAlert.title = "Alerta"
        myAlert.message = myBuffer
        myAlert.addButtonWithTitle("OK")
        myAlert.show()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

















